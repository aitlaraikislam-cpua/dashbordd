# AERONEX — Aircraft Maintenance Intelligence

Application analytique Streamlit pour explorer les ordres de travail, la flotte, la fiabilité, les systèmes ATA, les coûts et l’impact opérationnel.

## Démarrage

```bash
python -m venv .venv
# Windows : .venv\\Scripts\\activate
# macOS / Linux : source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

Le fichier source est `data/ait_laraik_islam.csv`. Remplace-le par un CSV compatible si nécessaire : les noms de colonnes attendus sont utilisés dans `utils/data_loader.py`, `utils/calculations.py` et `app.py`.

## Connexion

Pour un environnement local de démonstration, les identifiants par défaut sont `admin` / `demo-Aviation-2026`. **Ils ne doivent pas être utilisés en production.**

Configure tes identifiants dans `.streamlit/secrets.toml` :

```toml
[auth]
username = "ton_utilisateur"
password = "un_mot_de_passe_long_et_unique"
```

Ou via les variables d’environnement `AMA_USERNAME` et `AMA_PASSWORD`. Ne publie jamais `secrets.toml` et ne versionne aucun secret.

## Séparation des informations

AERONEX distingue explicitement trois catégories :

1. **Données réelles** — enregistrements et champs chargés du CSV fourni (ordres de travail, immatriculations, escales, coûts, dates, défauts, statuts, etc.).
2. **Indicateurs et alertes calculés** — KPI, agrégations, classements et listes AOG / High / MEL / défauts répétitifs construites à partir des champs source et des filtres actifs. Les règles sont visibles dans le code Python.
3. **Éléments décoratifs** — photographie de hangar, images illustratives d’avion / moteur / maintenance, silhouette d’avion, logo, effets CSS et textes de présentation. Les images illustratives ne sont pas reliées à une immatriculation, un WO ou un événement du CSV et ne sont jamais utilisées dans les calculs.

Les alertes sont des signaux analytiques dérivés des données disponibles. Elles ne sont pas temps réel et ne constituent ni un diagnostic technique, ni une décision de dispatch, ni une déclaration de navigabilité.

## Fonctionnalités conservées

- Authentification de démonstration et déconnexion
- Thème sombre / clair
- Navigation par modules et filtres globaux
- KPI et analyses Plotly
- Analyses flotte, fiabilité, ATA, coûts, immobilisation et retards
- Centre d’alertes analytiques
- Exploration, recherche et export CSV
- Contrôle qualité des données sans suppression silencieuse des lignes

## Personnalisation

- `config.py` : titre, sous-titre et navigation
- `assets/styles.css` : design, responsive, animations et thèmes
- `assets/` : photographie de couverture et visuels illustratifs locaux (aucun chargement d’image externe à l’exécution)
- `components/charts.py` : palette et style Plotly
- `components/login.py` : écran de connexion
- `utils/data_loader.py` : chargement et qualité des données
- `utils/calculations.py` : règles de calcul des KPI
- `app.py` : pages, filtres et visualisations

## Limites à connaître

Les résultats dépendent de la qualité et de la couverture du CSV. Une donnée absente n’est pas assimilée à zéro lorsque le champ reste manquant. Vérifie les règles métier et la signification des champs avec les responsables maintenance avant toute utilisation opérationnelle.


## Module Activité quotidienne
Le module **Activité quotidienne** regroupe les ordres de travail par date d'ouverture et affiche des cartes avion avec immatriculation, type, escale, système ATA, priorité, statut et horaires d'intervention. Il propose aussi un export CSV par journée.

**Limite de la source :** le CSV contient des données de maintenance, pas des horaires de vols ni une télémétrie de suivi aérien. Les cartes décrivent donc l'activité de maintenance réellement présente dans le fichier et ne doivent pas être interprétées comme un suivi de vols en temps réel.


## Version visuelle multilingue
- Choix de langue dès l'écran de connexion : français, anglais ou espagnol.
- Navigation traduite et possibilité de changer la langue depuis la barre latérale.
- Profils visuels par type de flotte et fiche avion individuelle avec historique récent.
- Cartes quotidiennes enrichies de photographies d'illustration.
- Vues visuelles pour les systèmes ATA, les coûts, les alertes et les ordres de travail afin de réduire l'usage des tableaux.
- Les photographies sont des illustrations d'aéronefs/environnements et ne prétendent pas représenter l'immatriculation exacte.


## Mise à jour de l'interface dashboard
- Le sélecteur de langue est disponible dès l'écran de connexion (français, anglais, espagnol).
- La page d'accueil comprend une bannière photo et des raccourcis visuels vers les modules principaux.
- Les pages Fiabilité, Analyse ATA et Rapports disposent de bannières photographiques thématiques.
- Les photographies restent illustratives ; les chiffres, alertes et fiches sont calculés à partir du CSV.
- Le journal quotidien décrit les interventions de maintenance, et ne simule pas des vols ni un suivi GPS.


## Interface AERONEX — cockpit visuel

La page « Vue d’ensemble » utilise une disposition cockpit : suivi de flotte, réseau des escales du jeu de données, alertes calculées, comparaison des types d’avions, journal récent et actions rapides. La carte représente les aéroports associés aux ordres de maintenance du CSV ; elle ne prétend pas afficher des positions avion ou des trajectoires en temps réel.
