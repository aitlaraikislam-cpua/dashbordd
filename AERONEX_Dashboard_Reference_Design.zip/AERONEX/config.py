APP_TITLE = "AERONEX — Aircraft Maintenance Intelligence"
APP_SUBTITLE = "Fleet performance • Reliability engineering • Maintenance operations"
PAGE_NAMES = [
    "Vue d’ensemble", "Flotte", "Activité quotidienne", "Fiabilité", "Analyse ATA",
    "Atelier & coûts", "Immobilisation & retards", "Alertes",
    "Ordres de travail", "Rapports & recommandations"
]
